import sqlite3
conn = sqlite3.connect('d:/filework/release-prep-worktree/meta/architecture.db')
c = conn.cursor()
c.execute('PRAGMA table_info(products)')
for row in c.fetchall():
    print(row)
print('---')
c.execute('SELECT * FROM products LIMIT 5')
for row in c.fetchall():
    print(row)
print('---')
c.execute('SELECT count(*) FROM products')
print('product count:', c.fetchone())

# -*- coding: utf-8 -*-
"""
菜单权限表初始化脚本

创建 menu_permissions 表并插入系统菜单数据
每个菜单关联对应的业务对象（BO）

[H14.1] 单一事实源约定：
    yaml  meta/schemas/*.yaml  import_export: 段
        是导入导出权限的"业务能力声明" (ImportExportService 能否工作)
    menu menus.bo_bindings[*].include_actions
        是权限矩阵 UI 推导源 (_derive_bo_permission_groups 的 actions_map)
    步骤 6.5 自动从前者派生后者, 消除两层独立维护导致的漂移.
    人工显式声明 (yaml 未配但 menu 声明, 如 user_group 的 assign)
    通过反向 KEEP 保留, 不被本脚本删除.
"""

import sqlite3
import os
import json
import sys
import io
import glob
import yaml
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')


def init_menu_permissions(db_path):
    """初始化菜单权限表和 menus 导航表数据（元数据驱动）"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    print("=" * 60)
    print("初始化菜单权限表 & menus 导航表")
    print("=" * 60)

    # ========== 步骤1：创建 menu_permissions 表（权限） ==========
    print("\n[步骤1] 创建 menu_permissions 表...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS menu_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            menu_code VARCHAR(200) UNIQUE NOT NULL,
            menu_name VARCHAR(200) NOT NULL,
            menu_path VARCHAR(500) NOT NULL,
            required_permissions TEXT,
            required_any_permission INTEGER DEFAULT 0,
            parent_menu VARCHAR(200),
            icon VARCHAR(200),
            sort_order INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            data_permission_hint TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_menu_permission_code ON menu_permissions(menu_code)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_menu_permission_parent ON menu_permissions(parent_menu)")

    # 创建 role_menu_permissions 关联表（many-to-many: role <-> menu_permission）
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS role_menu_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role_id INTEGER NOT NULL,
            menu_code VARCHAR(200) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(role_id, menu_code)
        )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_rmp_role ON role_menu_permissions(role_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_rmp_menu ON role_menu_permissions(menu_code)")

    # ========== 步骤2：创建 menus 表（导航） ==========
    print("\n[步骤2] 创建 menus 导航表...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS menus (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            menu_code VARCHAR(200) UNIQUE NOT NULL,
            menu_name VARCHAR(200) NOT NULL,
            menu_path VARCHAR(500) NOT NULL DEFAULT '',
            page_type VARCHAR(200) DEFAULT 'object_list',
            object_types TEXT DEFAULT '[]',
            primary_object_type VARCHAR(200) DEFAULT '',
            page_config TEXT DEFAULT '{}',
            parent_menu VARCHAR(200) DEFAULT '',
            icon VARCHAR(200) DEFAULT '',
            color VARCHAR(200) DEFAULT '',
            description VARCHAR(500) DEFAULT '',
            sort_order INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            show_in_sidebar INTEGER DEFAULT 1,
            auto_generated INTEGER DEFAULT 0
        )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_menus_code ON menus(menu_code)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_menus_parent ON menus(parent_menu)")

    # 兼容旧表：补充 bo_bindings / required_permissions 列
    try:
        cursor.execute("ALTER TABLE menus ADD COLUMN bo_bindings TEXT DEFAULT '[]'")
    except Exception:
        pass
    try:
        cursor.execute("ALTER TABLE menus ADD COLUMN required_permissions TEXT DEFAULT '[]'")
    except Exception:
        pass

    print("  [OK] 两表创建完成")

    # ========== 步骤3：检查 menu_permissions 是否已有数据 ==========
    print("\n[步骤3] 检查现有数据...")
    cursor.execute("SELECT COUNT(*) FROM menu_permissions")
    perm_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM menus")
    menus_count = cursor.fetchone()[0]

    if perm_count > 0:
        print(f"  ⏭️  已有 {perm_count} 条权限数据")

    if menus_count > 0:
        print(f"  ⏭️  已有 {menus_count} 条导航数据")

    # ========== 步骤4：系统菜单定义（元数据驱动） ==========
    print("\n[步骤4] 插入系统菜单数据...")

    system_menus = [
        {
            'menu_code': 'dashboard',
            'menu_name': '仪表盘',
            'menu_path': '/dashboard',
            'icon': 'Home',
            'color': '#3b82f6',
            'sort_order': 0,
            'page_type': 'dashboard',
            'primary_object_type': '',
            'object_types': json.dumps([]),
            'required_permissions': json.dumps([]),
            'data_permission_hint': None
        },
        {
            'menu_code': 'arch-data',
            'menu_name': '架构数据管理',
            'menu_path': '/data',
            'icon': 'FolderOpened',
            'color': '#10b981',
            'sort_order': 20,
            'page_type': 'multi_object_hub',
            'primary_object_type': 'domain',
            'object_types': json.dumps(['domain', 'sub_domain', 'service_module', 'relationship', 'audit_log']),
            'bo_bindings': json.dumps([
                {'bo_id': 'domain', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
                # [H14.1] 同步 yaml import_export: sub_domain / service_module / business_object 支持导入导出
                {'bo_id': 'sub_domain', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
                {'bo_id': 'service_module', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
                {'bo_id': 'business_object', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
                # 🆕 BMRD-2026-06-14 方案A: 关系对象随架构数据自动带入 (FR-013 轻量版)
                # 关系数据是跨层级的纽带, 架构数据管理页操作 domain/sub_domain/... 时必然要查阅
                # 其相互之间的关系, role='derived' 表示派生而非主 BO
                # [H14.1] relationship yaml 支持 import, 补全
                {'bo_id': 'relationship', 'role': 'derived', 'include_actions': ['read', 'export', 'import']},
                # 🆕 BMRD-2026-06-14 审计日志自动带入
                # domain 详情页"操作日志" tab 需要 read 权限, 紧化 v1 endpoint 后
                # (v1 现在也校验 audit_log:read) 必须显式 grant 才能看到
                # [H14.1] audit_log yaml import_enabled=false, 只保留 export
                {'bo_id': 'audit_log', 'role': 'derived', 'include_actions': ['read', 'export']},
            ]),
            'required_permissions': json.dumps([
                'domain:create', 'domain:read', 'domain:update', 'domain:delete', 'domain:export', 'domain:import',
                'sub_domain:create', 'sub_domain:read', 'sub_domain:update', 'sub_domain:delete',
                'service_module:create', 'service_module:read', 'service_module:update', 'service_module:delete',
                'business_object:create', 'business_object:read', 'business_object:update', 'business_object:delete',
                # 🆕 关系对象 (derived) 的最低权限
                'relationship:read', 'relationship:export',
                # 🆕 审计日志 (derived) 的最低权限 (操作日志 tab 必需)
                'audit_log:read', 'audit_log:export',
            ]),
            'data_permission_hint': json.dumps({
                'resource_types': ['domain', 'sub_domain', 'relationship', 'audit_log'],
                'message': '建议分配领域/子域/关系/审计日志数据权限 (关系和审计随架构数据自动带入)'
            })
        },
        {
            'menu_code': 'product-management',
            'menu_name': '产品版本管理',
            'menu_path': '/product-management',
            'icon': 'Box',
            'color': '#06b6d4',
            'sort_order': 40,
            'page_type': 'object_list',
            'primary_object_type': 'product',
            'object_types': json.dumps(['product']),
            'bo_bindings': json.dumps([
                # [H14.1] 同步 yaml import_export: product / version 支持导入导出
                {'bo_id': 'product', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
                {'bo_id': 'version', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
            ]),
            'required_permissions': json.dumps([
                'product:create', 'product:read', 'product:update', 'product:delete',
            ]),
            'data_permission_hint': json.dumps({
                'resource_types': ['product'],
                'message': '建议分配产品数据权限'
            })
        },
        {
            'menu_code': 'system',
            'menu_name': '系统管理',
            'menu_path': '',
            'icon': 'Setting',
            'color': '#6b7280',
            'sort_order': 50,
            'page_type': 'custom_page',
            'primary_object_type': '',
            'object_types': json.dumps([]),
            'required_permissions': json.dumps([]),
            'data_permission_hint': None
        },
        {
            'menu_code': 'user-permission',
            'menu_name': '用户与权限管理',
            'menu_path': '/user-permission',
            'icon': 'User',
            'color': '#ef4444',
            'sort_order': 51,
            'parent_menu': '',
            'page_type': 'multi_object_hub',
            'primary_object_type': 'user',
            'object_types': json.dumps(['user', 'role', 'user_group']),
            'bo_bindings': json.dumps([
                # [H14.1] 同步 yaml import_export: user / role 支持导入导出
                # user_group yaml 未配 import_export (无导入导出服务), 显式声明的 assign/unassign/grant/revoke 由 6.5 反向 KEEP
                {'bo_id': 'user', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
                {'bo_id': 'role', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export', 'import']},
                {'bo_id': 'user_group', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'assign', 'unassign', 'grant', 'revoke']},
            ]),
            'required_permissions': json.dumps([
                'user:create', 'user:read', 'user:update', 'user:delete',
                'role:create', 'role:read', 'role:update', 'role:delete',
                'user_group:create', 'user_group:read', 'user_group:update', 'user_group:delete',
                'user_group:assign', 'user_group:unassign', 'user_group:grant', 'user_group:revoke',
            ]),
            'data_permission_hint': json.dumps({
                'resource_types': ['user', 'role', 'user_group'],
                'message': '需要用户管理相关权限'
            })
        },
        {
            'menu_code': 'business-config',
            'menu_name': '业务配置',
            'menu_path': '/business-config',
            'icon': 'Tools',
            'color': '#8b5cf6',
            'sort_order': 52,
            'parent_menu': 'system',
            'page_type': 'multi_object_hub',
            'primary_object_type': 'enum_type',
            'object_types': json.dumps(['enum_type']),
            'bo_bindings': json.dumps([
                # [H14.1] 同步 yaml import_export: enum_type 仅 export_enabled=true (import_enabled=false)
                {'bo_id': 'enum_type', 'role': 'primary', 'include_actions': ['create', 'read', 'update', 'delete', 'list', 'export']},
            ]),
            'required_permissions': json.dumps([
                'enum_type:create', 'enum_type:read', 'enum_type:update', 'enum_type:delete',
            ]),
            'data_permission_hint': json.dumps({
                'resource_types': ['service_module'],
                'message': '建议分配服务模块数据权限'
            }),
        },
        {
            'menu_code': 'audit-log',
            'menu_name': '日志管理',
            'menu_path': '/system-admin',
            'icon': 'List',
            'color': '#64748b',
            'sort_order': 53,
            'parent_menu': 'system',
            'page_type': 'object_list',
            'primary_object_type': 'audit_log',
            'object_types': json.dumps(['audit_log']),
            'bo_bindings': json.dumps([
                # [H14.1] 同步 yaml import_export: audit_log 仅 export_enabled=true (import_enabled=false)
                {'bo_id': 'audit_log', 'role': 'primary', 'include_actions': ['read', 'export']},
            ]),
            # [FIX 2026-06-14] 菜单 "日志管理" 限定 super-admin only.
            #   any(p in user_perms for p in required) 语义下, 普通权限 (如 audit_log:read) 会让所有业务用户都能看见.
            #   详情 tab 的操作日志 (audit_log:read) 跟菜单的日志管理 (admin only) 是两个独立维度.
            #   '*' 表示 "super-admin" (admin 角色自带, 普通用户没有).
            'required_permissions': json.dumps([
                '*',
            ]),
            'data_permission_hint': json.dumps({
                'resource_types': ['audit_log'],
                'message': '建议分配审计日志查看权限'
            })
        },
    ]

    # ========== 步骤4.5：清理已废弃菜单 ==========
    deprecated_codes = ['product-version']
    for code in deprecated_codes:
        cursor.execute("DELETE FROM menus WHERE menu_code = ?", [code])
        cursor.execute("DELETE FROM menu_permissions WHERE menu_code = ?", [code])
    conn.commit()

    # ========== 步骤5：写入/更新 menu_permissions 表（权限） ==========
    print("\n[步骤5] 同步 menu_permissions 表...")
    for menu in system_menus:
        cursor.execute(
            "SELECT menu_code FROM menu_permissions WHERE menu_code = ?",
            [menu['menu_code']]
        )
        if cursor.fetchone():
            cursor.execute("""
                UPDATE menu_permissions SET
                    menu_name = ?, menu_path = ?,
                    required_permissions = ?, parent_menu = ?,
                    icon = ?, sort_order = ?, is_active = 1,
                    data_permission_hint = ?
                WHERE menu_code = ?
            """, [
                menu['menu_name'],
                menu['menu_path'],
                menu['required_permissions'],
                menu.get('parent_menu'),
                menu.get('icon'),
                menu['sort_order'],
                menu.get('data_permission_hint'),
                menu['menu_code'],
            ])
            print(f"  [OK] perm: {menu['menu_name']} ({menu['menu_code']})")
        else:
            cursor.execute("""
                INSERT INTO menu_permissions
                (menu_code, menu_name, menu_path, required_permissions, required_any_permission,
                 parent_menu, icon, sort_order, is_active, data_permission_hint)
                VALUES (?, ?, ?, ?, 0, ?, ?, ?, 1, ?)
            """, [
                menu['menu_code'],
                menu['menu_name'],
                menu['menu_path'],
                menu['required_permissions'],
                menu.get('parent_menu'),
                menu.get('icon'),
                menu['sort_order'],
                menu.get('data_permission_hint')
            ])
            print(f"  [OK] perm: {menu['menu_name']} ({menu['menu_code']})")

    # ========== 步骤6：同步 menus 导航表（每次启动 UPSERT） ==========
    print("\n[步骤6] 同步 menus 导航表...")
    for menu in system_menus:
        cursor.execute(
            "SELECT menu_code FROM menus WHERE menu_code = ?",
            [menu['menu_code']]
        )
        if cursor.fetchone():
            cursor.execute("""
                UPDATE menus SET
                    menu_name = ?, menu_path = ?, page_type = ?,
                    primary_object_type = ?, object_types = ?,
                    bo_bindings = ?, required_permissions = ?,
                    parent_menu = ?, icon = ?, color = ?,
                    description = ?, sort_order = ?
                WHERE menu_code = ?
            """, [
                menu['menu_name'],
                menu['menu_path'],
                menu.get('page_type', 'custom_page'),
                menu.get('primary_object_type', ''),
                menu.get('object_types', '[]'),
                menu.get('bo_bindings', '[]'),
                menu['required_permissions'],
                menu.get('parent_menu', ''),
                menu.get('icon', ''),
                menu.get('color', ''),
                menu.get('description', ''),
                menu['sort_order'],
                menu['menu_code'],
            ])
            print(f"  [OK] nav:  {menu['menu_name']} ({menu['menu_code']}) [{menu.get('page_type')}]")
        else:
            cursor.execute("""
                INSERT INTO menus
                (menu_code, menu_name, menu_path, page_type, object_types,
                 primary_object_type, bo_bindings, required_permissions,
                 parent_menu, icon, color, description,
                 sort_order, is_active, show_in_sidebar, auto_generated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 0)
            """, [
                menu['menu_code'],
                menu['menu_name'],
                menu['menu_path'],
                menu.get('page_type', 'custom_page'),
                menu.get('object_types', '[]'),
                menu.get('primary_object_type', ''),
                menu.get('bo_bindings', '[]'),
                menu['required_permissions'],
                menu.get('parent_menu', ''),
                menu.get('icon', ''),
                menu.get('color', ''),
                menu.get('description', ''),
                menu['sort_order'],
            ])
            print(f"  [OK] nav:  {menu['menu_name']} ({menu['menu_code']}) [{menu.get('page_type')}]")

    # ========== 步骤6.5: yaml import_export → menu bo_bindings 自动对齐 ==========
    # [H14.1] 单一事实源同步: 从 meta/schemas/*.yaml 读 import_export.import_enabled /
    # export_enabled, 自动补全到 menus.bo_bindings 对应 BO 的 include_actions.
    # 不删除人工显式声明 (yaml 未配但 menu 声明), 用 [KEEP] 日志标记.
    print("\n[步骤6.5] 对齐 yaml import_export → menu bo_bindings ...")
    schemas_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'schemas')
    yaml_action_map = {}  # bo_id -> {'import': bool, 'export': bool}
    for yaml_path in glob.glob(os.path.join(schemas_dir, '*.yaml')):
        try:
            with open(yaml_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        except Exception as e:
            print(f"  [WARN] 解析失败 {os.path.basename(yaml_path)}: {e}")
            continue
        if not data or 'id' not in data:
            continue
        ie = data.get('import_export')
        if not ie:
            continue
        bo_id = data['id']
        yaml_action_map[bo_id] = {
            'import': bool(ie.get('import_enabled', False)),
            'export': bool(ie.get('export_enabled', False)),
        }

    align_total = 0
    keep_total = 0
    for menu in system_menus:
        menu_code = menu['menu_code']
        # 从 DB 读最新 bo_bindings (步骤 6 UPSERT 后)
        cursor.execute("SELECT bo_bindings FROM menus WHERE menu_code = ?", [menu_code])
        row = cursor.fetchone()
        if not row or not row[0]:
            continue
        try:
            bindings = json.loads(row[0])
        except Exception:
            continue
        if not bindings:
            continue
        menu_dirty = False
        for b in bindings:
            bo_id = b.get('bo_id')
            if not bo_id:
                continue
            include_actions = b.get('include_actions', [])
            # 1) 从 yaml 派生 import/export
            yaml_acts = yaml_action_map.get(bo_id)
            if yaml_acts:
                for act_key, enabled in yaml_acts.items():
                    if enabled and act_key not in include_actions:
                        include_actions.append(act_key)
                        print(f"  [ALIGN] {menu_code}/{bo_id}: +{act_key}")
                        align_total += 1
                        menu_dirty = True
            # 2) 反向 KEEP: yaml 未配 export/import 但 menu 显式声明, 保留 (人工意图)
            for act_key in ('export', 'import'):
                if act_key in include_actions:
                    if not yaml_acts or not yaml_acts.get(act_key):
                        keep_total += 1
                        # 不打日志避免噪音, 仅在最终统计报告
        if menu_dirty:
            cursor.execute(
                "UPDATE menus SET bo_bindings = ? WHERE menu_code = ?",
                [json.dumps(bindings, ensure_ascii=False), menu_code]
            )
    if align_total == 0 and keep_total == 0:
        print("  [OK] 无需对齐 (yaml ↔ menu 已一致)")
    else:
        print(f"  [OK] 对齐完成: +{align_total} 个独立动作, 保留 {keep_total} 个人工显式声明")

    print("\n[步骤7] 验证初始化结果...")

    cursor.execute("SELECT COUNT(*) FROM menus")
    nav_count = cursor.fetchone()[0]
    print(f"  menus 导航表: {nav_count} 条")

    cursor.execute("SELECT COUNT(*) FROM menu_permissions")
    perm_count = cursor.fetchone()[0]
    print(f"  menu_permissions 权限表: {perm_count} 条")

    cursor.execute("""
        SELECT menu_name, page_type, primary_object_type, parent_menu
        FROM menus ORDER BY sort_order
    """)
    menus = cursor.fetchall()

    print("\n  菜单列表 (page_type):")
    for name, page_type, primary_obj, parent in menus:
        indent = "  " if parent else ""
        print(f"    {indent}- {name} [{page_type}] {primary_obj or ''}")

    conn.commit()

    # ========== 步骤7.5：清理 menu_permissions 表中不属于白名单的条目 ==========
    print("\n[步骤7.5] 清理 menu_permissions 表冗余条目...")
    valid_perm_codes = {m['menu_code'] for m in system_menus}
    valid_perm_codes.add('task-management')

    cursor.execute("SELECT menu_code, menu_name FROM menu_permissions")
    all_perm_entries = cursor.fetchall()
    removed = 0
    for menu_code, menu_name in all_perm_entries:
        if menu_code not in valid_perm_codes:
            cursor.execute("DELETE FROM menu_permissions WHERE menu_code = ?", [menu_code])
            print(f"  [SYMBOL]  stale perm: {menu_name} ({menu_code})")
            removed += 1

    if removed == 0:
        print("  [OK] 无冗余条目")
    else:
        print(f"  [OK] 清理了 {removed} 条冗余菜单权限")

    # 也清理 menus 表中的冗余条目
    print("\n[步骤7.6] 清理 menus 导航表冗余条目...")
    valid_nav_codes = {m['menu_code'] for m in system_menus}
    valid_nav_codes.add('task-management')
    valid_nav_codes.add('task-definitions')
    valid_nav_codes.add('task-queues')
    valid_nav_codes.add('task-executions')
    valid_nav_codes.add('ai-async-tasks')

    cursor.execute("SELECT menu_code, menu_name, auto_generated FROM menus WHERE auto_generated = 0")
    all_manual_menus = cursor.fetchall()
    removed_nav = 0
    for menu_code, menu_name, _ in all_manual_menus:
        if menu_code not in valid_nav_codes:
            cursor.execute("DELETE FROM menus WHERE menu_code = ?", [menu_code])
            print(f"  [SYMBOL]  stale nav: {menu_name} ({menu_code})")
            removed_nav += 1

    if removed_nav == 0:
        print("  [OK] 无冗余条目")
    else:
        print(f"  [OK] 清理了 {removed_nav} 条冗余导航菜单")

    # ========== 步骤7.7：FR-013 轻量版 — 把菜单权限展开到角色 ==========
    # 背景 (BMRD-2026-06-14): 菜单的 required_permissions 只是元数据声明, 运行时权限
    # 检查 (permission_interceptor.py) 走 role_permissions 表, 中间链路断了导致
    # 角色访问菜单后做具体操作仍 403。修复: 把 role_menu_permissions 关联的
    # 菜单的 required_permissions 自动 grant 到 role_permissions。
    # 注: 这是 init-time 展开, 跟 SAP SU24 的"事务码 → 默认授权对象"等价。
    print("\n[步骤7.7] 展开菜单权限到角色 (FR-013 轻量版)...")
    cursor.execute("""
        SELECT rmp.role_id, r.code, mp.required_permissions
        FROM role_menu_permissions rmp
        JOIN roles r ON r.id = rmp.role_id
        JOIN menu_permissions mp ON mp.menu_code = rmp.menu_code
        WHERE r.is_active = 1
    """)
    role_menu_rows = cursor.fetchall()
    total_granted = 0
    roles_touched = 0
    for role_id, role_code, req_perms_str in role_menu_rows:
        if not req_perms_str:
            continue
        try:
            req_perms = json.loads(req_perms_str)
        except Exception:
            continue
        granted_for_role = 0
        for perm_code in req_perms:
            cursor.execute("SELECT id FROM permissions WHERE code = ?", [perm_code])
            perm_row = cursor.fetchone()
            if not perm_row:
                # 权限定义不存在, 跳过 (init_menus 会补)
                continue
            perm_id = perm_row[0]
            cursor.execute("""
                SELECT 1 FROM role_permissions
                WHERE role_id = ? AND permission_id = ?
            """, [role_id, perm_id])
            if cursor.fetchone():
                continue  # 已存在
            cursor.execute("""
                INSERT INTO role_permissions (role_id, permission_id, granted)
                VALUES (?, ?, 1)
            """, [role_id, perm_id])
            granted_for_role += 1
        if granted_for_role > 0:
            roles_touched += 1
            total_granted += granted_for_role
            rel_count = sum(1 for p in req_perms if 'relationship' in p)
            print(f"  ✅ {role_code}: +{granted_for_role} permissions (含 {rel_count} relationship)")

    if total_granted == 0:
        print("  [OK] 无需展开 (所有权限已存在)")
    else:
        print(f"  [OK] 跨 {roles_touched} 个角色共授权 {total_granted} 条 permissions")

    print("\n" + "=" * 60)
    print("[OK] 菜单权限表 & 导航表初始化完成！")
    print("=" * 60)

    conn.close()


if __name__ == '__main__':
    # [H14.1] 支持通过环境变量指定 db_path (与 server.py:455-456 行为一致)
    # 优先级: CLI 参数 > ARCH_DB_PATH > SQLITE_DB_PATH > meta/architecture.db
    db_path = None
    if len(sys.argv) > 1:
        db_path = sys.argv[1]
    if not db_path:
        db_path = os.environ.get('ARCH_DB_PATH')
    if not db_path:
        db_path = os.environ.get('SQLITE_DB_PATH')
    if not db_path:
        db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'architecture.db')
    print(f"数据库路径: {db_path}")
    init_menu_permissions(db_path)
